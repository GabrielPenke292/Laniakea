<?= $this->extend('template/head') ?>
<?= $this->extend('template/header') ?>
<?= $this->section('content') ?>

<?= $this->endSection() ?>